import numpy as np

PARAMETERS = list(np.arange(-1, 1.25, 0.25))
PARAMETERS.extend([0.125, -0.125])